/* ══════════ Authentic Belgian Waffle — main.js ══════════ */

/* ── Dark / Light Theme ── */
function initTheme() {
  const t = localStorage.getItem('abw_theme') || 'light';
  document.documentElement.setAttribute('data-theme', t);
  const ico = document.getElementById('themeIco');
  if (ico) ico.className = t === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
}
document.getElementById('themeBtn')?.addEventListener('click', () => {
  const cur = document.documentElement.getAttribute('data-theme');
  const nxt = cur === 'light' ? 'dark' : 'light';
  document.documentElement.setAttribute('data-theme', nxt);
  localStorage.setItem('abw_theme', nxt);
  const ico = document.getElementById('themeIco');
  if (ico) ico.className = nxt === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
});

/* ── Navbar scroll shadow ── */
window.addEventListener('scroll', () => {
  document.getElementById('navbar')?.classList.toggle('scrolled', window.scrollY > 40);
});

/* ── Mobile hamburger ── */
document.getElementById('hamburger')?.addEventListener('click', () => {
  document.getElementById('navLinks')?.classList.toggle('open');
});

/* ── Toast notifications ── */
function showToast(msg, type = 'success') {
  const wrap = document.getElementById('toastWrap');
  if (!wrap) return;
  const t = document.createElement('div');
  t.className = `toast toast-${type}`;
  t.innerHTML = `<i class="fas fa-${type==='success'?'check-circle':type==='error'?'times-circle':'info-circle'}"></i> ${msg}`;
  wrap.appendChild(t);
  setTimeout(() => t.remove(), 3200);
}

/* ── Chatbot ── */
const chatReplies = {
  waffle:     '🧇 Our waffles are legendary! Try the Nutella Banana Waffle, Lotus Biscoff Waffle, or the Classic Belgian!',
  'ice cream':'🍦 Ice cream lovers! Triple Chocolate Sundae and Cookie Dough are top picks!',
  icecream:   '🍦 Ice cream lovers! Triple Chocolate Sundae and Cookie Dough are top picks!',
  pancake:    '🥞 Pancake stacks galore! Try the Nutella Tower or Red Velvet Pancakes!',
  milkshake:  '🥤 Thick shakes alert! Oreo Overload and Lotus Biscoff Shake are bestsellers!',
  shake:      '🥤 Thick shakes alert! Oreo Overload and Lotus Biscoff Shake are bestsellers!',
  brownie:    '🍫 Brownie heaven! Nutella Swirl and S\'mores Brownie are absolute bestsellers!',
  cake:       '🎂 Our Waffle Cakes are showstoppers — try the Belgian or Rainbow Waffle Cake!',
  chocolate:  '🍫 Chocoholic? Go for Triple Chocolate Sundae, Choc Fudge Shake, or Nutella Brownie!',
  nutella:    '😍 Nutella fan? Try Nutella Banana Waffle, Nutella Pancake Tower, and Nutella Swirl Brownie!',
  biscoff:    '🍪 Biscoff lover? Lotus Biscoff Waffle, Biscoff Shake, and Biscoff Brownie await!',
  cheap:      '💰 Budget picks: Vanilla Scoop ₹99, Classic Waffle ₹149, Fudge Brownie ₹129!',
  popular:    '⭐ Bestsellers: Nutella Banana Waffle, Oreo Shake, Belgian Waffle Cake, Nutella Brownie!',
  hello:      '👋 Welcome to Authentic Belgian Waffle! Ask me about waffles, ice creams, pancakes, shakes, cakes or brownies!',
  hi:         '😊 Hi there! What are you craving? Waffles, pancakes, ice cream, milkshakes, or brownies?',
  veg:        '🌿 Great news — our entire menu is vegetarian-friendly! All 32 items are veg!',
  menu:       '🧇 We have 32 items across Waffles, Ice Creams, Pancakes, Milkshakes, Waffle Cakes & Brownies!',
};
function chatReply(msg) {
  const m = msg.toLowerCase();
  for (const [k, v] of Object.entries(chatReplies)) {
    if (m.includes(k)) return v;
  }
  return "🤔 Try asking about waffles, ice cream, pancakes, milkshakes, waffle cakes, brownies, or popular items!";
}
function sendChat() {
  const inp = document.getElementById('chatIn');
  const msg = inp?.value.trim();
  if (!msg) return;
  const msgs = document.getElementById('chatMsgs');
  msgs.innerHTML += `<div class="user-msg">${msg}</div>`;
  inp.value = '';
  const typing = document.createElement('div');
  typing.className = 'bot-msg'; typing.textContent = '...';
  msgs.appendChild(typing);
  msgs.scrollTop = msgs.scrollHeight;
  setTimeout(() => {
    typing.textContent = chatReply(msg);
    msgs.scrollTop = msgs.scrollHeight;
  }, 650);
}
document.getElementById('chatToggle')?.addEventListener('click', () =>
  document.getElementById('chatBox')?.classList.toggle('open'));
document.getElementById('chatClose')?.addEventListener('click', () =>
  document.getElementById('chatBox')?.classList.remove('open'));
document.getElementById('chatSend')?.addEventListener('click', sendChat);
document.getElementById('chatIn')?.addEventListener('keypress', e => {
  if (e.key === 'Enter') sendChat();
});

/* ── Payment tab switching ── */
function selPay(btn, type) {
  document.querySelectorAll('.pay-tab').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  ['upi','card','cod'].forEach(t => {
    const el = document.getElementById(t + 'Section');
    if (el) el.style.display = t === type ? 'block' : 'none';
  });
}

/* ── Wishlist heart toggle (AJAX) ── */
function toggleWish(foodId, btn) {
  fetch(`${BASE_URL}/api/wishlist.php`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ food_id: foodId })
  })
  .then(r => r.json())
  .then(d => {
    if (d.success) {
      btn.textContent = d.action === 'added' ? '❤️' : '🤍';
      showToast(d.action === 'added' ? '❤️ Added to wishlist!' : 'Removed from wishlist', 'info');
    } else {
      showToast(d.message || 'Please login first', 'error');
    }
  })
  .catch(() => showToast('Something went wrong', 'error'));
}

/* ── Cart quantity AJAX update ── */
function updateQty(cartId, delta) {
  const inp = document.getElementById('qty-' + cartId);
  if (!inp) return;
  const newQty = Math.max(1, parseInt(inp.value) + delta);
  inp.value = newQty;
  fetch(`${BASE_URL}/api/cart.php`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'update', cart_id: cartId, quantity: newQty })
  })
  .then(r => r.json())
  .then(d => {
    if (d.success) {
      document.getElementById('item-total-' + cartId).textContent = '₹' + d.item_total;
      document.getElementById('cart-subtotal').textContent = '₹' + d.subtotal;
      document.getElementById('cart-gst').textContent = '₹' + d.gst;
      document.getElementById('cart-total').textContent = '₹' + d.total;
      document.getElementById('cartBadge').textContent = d.cart_count;
    }
  });
}

/* ── Confirm payment (demo) ── */
function confirmPayment(btn) {
  btn.disabled = true;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
  setTimeout(() => {
    window.location.href = `${BASE_URL}/pages/order_success.php`;
  }, 2000);
}

/* ── Admin delete food ── */
function deleteFood(id) {
  if (!confirm('Delete this food item permanently?')) return;
  fetch(`${BASE_URL}/api/admin.php`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'delete_food', id })
  })
  .then(r => r.json())
  .then(d => {
    if (d.success) {
      document.getElementById('row-' + id)?.remove();
      showToast('Item deleted successfully', 'success');
    } else showToast(d.message, 'error');
  });
}

/* ── Toggle food availability ── */
function toggleAvail(id, current) {
  fetch(`${BASE_URL}/api/admin.php`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'toggle_avail', id, current })
  })
  .then(r => r.json())
  .then(d => {
    if (d.success) { location.reload(); }
    else showToast(d.message, 'error');
  });
}

/* ── Init ── */
initTheme();
