-- ============================================================
--  Authentic Belgian Waffle — MySQL Database Schema
--  Run this file once to set up the entire database.
--  Command: mysql -u root -p < database.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS belgian_waffle CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE belgian_waffle;

-- ─── USERS ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    email       VARCHAR(150) UNIQUE NOT NULL,
    password    VARCHAR(255) NOT NULL,          -- bcrypt hashed
    phone       VARCHAR(20),
    is_admin    TINYINT(1) DEFAULT 0,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ─── CATEGORIES ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS categories (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    slug        VARCHAR(50) UNIQUE NOT NULL,
    name        VARCHAR(100) NOT NULL,
    emoji       VARCHAR(10) NOT NULL,
    tagline     VARCHAR(100)
);

-- ─── FOOD ITEMS ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS food_items (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    category_id  INT NOT NULL,
    name         VARCHAR(150) NOT NULL,
    description  TEXT,
    price        DECIMAL(8,2) NOT NULL,
    rating       DECIMAL(3,1) DEFAULT 4.5,
    is_available TINYINT(1) DEFAULT 1,
    created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
);

-- ─── ORDERS ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS orders (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT,
    customer_name   VARCHAR(100),
    customer_email  VARCHAR(150),
    items_json      TEXT NOT NULL,              -- JSON snapshot of cart
    subtotal        DECIMAL(10,2) NOT NULL,
    gst             DECIMAL(10,2) NOT NULL,
    total           DECIMAL(10,2) NOT NULL,
    delivery_address TEXT,
    payment_method  VARCHAR(30) DEFAULT 'cod',
    status          ENUM('pending','confirmed','preparing','delivered','cancelled') DEFAULT 'pending',
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ─── CART ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cart (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    session_id  VARCHAR(100) NOT NULL,
    food_id     INT NOT NULL,
    quantity    INT DEFAULT 1,
    added_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (food_id) REFERENCES food_items(id) ON DELETE CASCADE
);

-- ─── WISHLIST ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS wishlist (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    food_id     INT NOT NULL,
    added_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_wish (user_id, food_id),
    FOREIGN KEY (user_id)  REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (food_id)  REFERENCES food_items(id) ON DELETE CASCADE
);

-- ─── CONTACT MESSAGES ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS contact_messages (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    email       VARCHAR(150) NOT NULL,
    message     TEXT NOT NULL,
    is_read     TINYINT(1) DEFAULT 0,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ─── RECIPES ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS recipes (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    title       VARCHAR(150) NOT NULL,
    category    VARCHAR(50),
    description TEXT,
    prep_time   INT,                            -- minutes
    difficulty  VARCHAR(20) DEFAULT 'Easy',
    servings    INT DEFAULT 4,
    ingredients TEXT,                           -- JSON array
    steps       TEXT,                           -- JSON array
    emoji       VARCHAR(10) DEFAULT '🧇'
);

-- ══════════════════════════════════════════════════════════
--  SEED DATA
-- ══════════════════════════════════════════════════════════

-- Admin user (password: admin123)
INSERT INTO users (name, email, password, is_admin) VALUES
('Admin', 'admin@belgianwaffle.in', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1);

-- Categories
INSERT INTO categories (slug, name, emoji, tagline) VALUES
('waffles',      'Waffles',      '🧇', 'Belgian style'),
('ice_cream',    'Ice Creams',   '🍦', 'Rich & creamy'),
('pancakes',     'Pancakes',     '🥞', 'Fluffy stacks'),
('milkshakes',   'Milkshakes',   '🥤', 'Thick & dreamy'),
('waffle_cakes', 'Waffle Cakes', '🎂', 'Celebration ready'),
('brownies',     'Brownies',     '🍫', 'Fudgy & rich');

-- Food Items — Waffles (cat 1)
INSERT INTO food_items (category_id, name, description, price, rating) VALUES
(1,'Classic Belgian Waffle','Light, crispy-edged waffle with a soft interior, served with maple syrup & butter',149.00,4.8),
(1,'Strawberry Waffle','Golden Belgian waffle topped with fresh strawberries, whipped cream & strawberry drizzle',199.00,4.9),
(1,'Nutella Banana Waffle','Warm waffle smothered in Nutella with caramelised banana slices and crushed hazelnuts',219.00,4.9),
(1,'Blueberry Cheesecake Waffle','Crispy waffle layered with cream cheese frosting and fresh blueberry compote',249.00,4.7),
(1,'Lotus Biscoff Waffle','Belgian waffle drizzled with Biscoff spread, crushed cookies & vanilla ice cream',229.00,4.8),
(1,"S'mores Waffle",'Toasted marshmallow, chocolate fudge and graham cracker crumble on a fluffy waffle',239.00,4.6);

-- Food Items — Ice Creams (cat 2)
INSERT INTO food_items (category_id, name, description, price, rating) VALUES
(2,'Classic Vanilla Scoop','Two generous scoops of rich, creamy Belgian vanilla bean ice cream',99.00,4.5),
(2,'Triple Chocolate Sundae','Dark, milk & white chocolate ice cream with hot fudge, sprinkles & a cherry on top',179.00,4.9),
(2,'Mango Sorbet','Refreshing dairy-free mango sorbet made from real Alphonso mangoes',129.00,4.6),
(2,'Strawberry Cheesecake Ice Cream','Creamy cheesecake ice cream swirled with strawberry jam & graham cracker pieces',159.00,4.7),
(2,'Cookie Dough Ice Cream','Vanilla ice cream loaded with chunks of edible cookie dough and chocolate chips',169.00,4.8);

-- Food Items — Pancakes (cat 3)
INSERT INTO food_items (category_id, name, description, price, rating) VALUES
(3,'Classic Buttermilk Pancakes','Fluffy stacked pancakes made with Belgian buttermilk, maple syrup & butter',149.00,4.7),
(3,'Blueberry Pancake Stack','Tall stack of fluffy pancakes bursting with fresh blueberries and lemon zest glaze',189.00,4.8),
(3,'Nutella Pancake Tower','Five-layer pancake tower filled with Nutella, topped with strawberries & powdered sugar',209.00,4.9),
(3,'Red Velvet Pancakes','Vibrant red velvet pancakes with cream cheese glaze and crushed Oreos',219.00,4.7),
(3,'Banana Foster Pancakes','Caramelised banana rum sauce over fluffy pancakes with a dusting of cinnamon',199.00,4.6);

-- Food Items — Milkshakes (cat 4)
INSERT INTO food_items (category_id, name, description, price, rating) VALUES
(4,'Classic Vanilla Shake','Thick, creamy vanilla milkshake blended with premium Belgian ice cream',149.00,4.6),
(4,'Oreo Overload Shake','Cookies & cream milkshake loaded with crushed Oreos, whipped cream & Oreo on top',179.00,4.9),
(4,'Strawberry Dream Shake','Fresh strawberry milkshake blended with real strawberries and vanilla ice cream',169.00,4.7),
(4,'Chocolate Fudge Shake','Rich dark chocolate milkshake with hot fudge drizzle and chocolate shavings',179.00,4.8),
(4,'Mango Lassi Shake','Tropical mango milkshake blended with yogurt, honey and a hint of cardamom',159.00,4.5),
(4,'Lotus Biscoff Shake','Creamy Biscoff milkshake with a caramel rim, whipped cream & Biscoff crumble',189.00,4.8);

-- Food Items — Waffle Cakes (cat 5)
INSERT INTO food_items (category_id, name, description, price, rating) VALUES
(5,'Belgian Waffle Cake','Layers of golden Belgian waffles stacked with whipped cream, fresh berries & ganache',349.00,4.9),
(5,'Chocolate Fudge Waffle Cake','Decadent waffle layers sandwiched with chocolate fudge frosting and chocolate ganache',379.00,4.8),
(5,'Strawberry Shortcake Waffle','Waffle cake with layers of fresh strawberry cream and strawberry compote',359.00,4.7),
(5,'Rainbow Waffle Cake','Colourful waffle cake with six layers of vibrant cream and rainbow sprinkles',399.00,4.8);

-- Food Items — Brownies (cat 6)
INSERT INTO food_items (category_id, name, description, price, rating) VALUES
(6,'Classic Fudge Brownie','Rich, dense chocolate fudge brownie with a crinkly top and gooey centre',129.00,4.8),
(6,'Nutella Swirl Brownie','Dark chocolate brownie with Nutella marble swirl and toasted hazelnuts',149.00,4.9),
(6,'Cream Cheese Brownie','Chocolate brownie with a thick cream cheese swirl baked right in',159.00,4.7),
(6,'Biscoff Brownie','Fudgy chocolate brownie topped with Biscoff spread and crushed Biscoff cookies',149.00,4.8),
(6,'Walnut Brownie','Classic chocolate brownie packed with crunchy walnuts and a dusting of sea salt',139.00,4.6),
(6,"S'mores Brownie",'Fudge brownie topped with toasted marshmallow fluff and a dark chocolate drizzle',159.00,4.7);

-- Sample Recipes
INSERT INTO recipes (title, category, description, prep_time, difficulty, servings, emoji, ingredients, steps) VALUES
('Classic Belgian Waffle','waffles','Light, crispy-edged waffles with a beautifully soft interior — the authentic Belgian way.',25,'Easy',4,'🧇',
 '["2 cups all-purpose flour","2 tbsp sugar","1 tsp baking powder","2 eggs, separated","1¾ cups buttermilk","½ cup melted butter","1 tsp vanilla extract"]',
 '["Whisk flour, sugar and baking powder together in a large bowl.","Mix egg yolks, buttermilk, butter and vanilla. Combine with dry ingredients.","Beat egg whites to stiff peaks, then gently fold into batter.","Pour into a hot waffle iron and cook 4–5 min until golden and crispy.","Serve immediately with maple syrup, butter and fresh berries."]'),

('Oreo Overload Milkshake','milkshakes','Insanely thick and creamy Oreo milkshake — better than any café version.',5,'Very Easy',2,'🥤',
 '["8 Oreo cookies","3 scoops vanilla ice cream","200ml whole milk","Whipped cream to top","Extra Oreos to garnish"]',
 '["Blend 6 Oreos, ice cream and milk until thick and creamy.","Pour into a chilled tall glass.","Top with whipped cream and crumble remaining Oreos on top.","Stick a whole Oreo on the rim and serve immediately!"]'),

('Classic Fudge Brownie','brownies','Rich, dense fudge brownies with a papery crinkle top and an impossibly gooey centre.',35,'Easy',16,'🍫',
 '["200g dark chocolate (70%)","150g butter","200g sugar","3 eggs","1 tsp vanilla","80g flour","30g cocoa powder"]',
 '["Melt butter and chocolate together over a bain-marie. Cool slightly.","Whisk eggs and sugar vigorously for 2 minutes until pale.","Fold chocolate mixture into eggs, then sift in flour and cocoa.","Pour into a lined 20cm tin. Bake at 180°C for 20–22 min.","Cool completely before cutting for the cleanest squares!"]'),

('Fluffy Buttermilk Pancakes','pancakes','Tall, cloud-like stacks of buttermilk pancakes — perfectly golden on the outside.',20,'Easy',8,'🥞',
 '["1½ cups flour","2 tbsp sugar","1 tsp baking soda","1 cup buttermilk","1 egg","2 tbsp melted butter","Pinch of salt"]',
 '["Mix dry ingredients in one bowl, wet in another.","Gently combine — lumps are fine! Don'\''t overmix.","Rest batter 5 minutes while pan heats to medium.","Pour ¼ cup portions; cook until bubbles form, then flip.","Stack high and serve with maple syrup and powdered sugar."]');
