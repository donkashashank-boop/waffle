<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
$sid   = getCartSessionId();
$items = fetchAll("SELECT c.quantity, f.id, f.name, f.price FROM cart c JOIN food_items f ON c.food_id=f.id WHERE c.session_id=?", 's', $sid);
if (empty($items)) { header('Location: ' . SITE_URL . '/pages/cart.php'); exit; }
$user      = getCurrentUser();
$subtotal  = (float)($_POST['subtotal'] ?? 0);
$gst       = (float)($_POST['gst']      ?? 0);
$total     = (float)($_POST['total']    ?? 0);
$address   = clean($_POST['address']    ?? '');
$payMethod = clean($_POST['payment_method'] ?? 'cod');
$custName  = $user ? $user['name']  : clean($_POST['customer_name']  ?? 'Guest');
$custEmail = $user ? $user['email'] : clean($_POST['customer_email'] ?? '');
$userId    = $user ? $user['id']    : null;
$itemsJson = json_encode(array_map(fn($i)=>['name'=>$i['name'],'price'=>$i['price'],'quantity'=>$i['quantity']], $items));
$db = db();
$stmt = $db->prepare("INSERT INTO orders (user_id, customer_name, customer_email, items_json, subtotal, gst, total, delivery_address, payment_method) VALUES (?,?,?,?,?,?,?,?,?)");
$stmt->bind_param('isssdddss', $userId, $custName, $custEmail, $itemsJson, $subtotal, $gst, $total, $address, $payMethod);
$stmt->execute();
query("DELETE FROM cart WHERE session_id=?", 's', $sid);
header('Location: ' . SITE_URL . '/pages/order_success.php'); exit;
