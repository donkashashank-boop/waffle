<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
header('Content-Type: application/json');
if (!isLoggedIn()) { echo json_encode(['success'=>false,'message'=>'Please login to use wishlist']); exit; }
$data    = json_decode(file_get_contents('php://input'), true);
$food_id = (int)($data['food_id'] ?? 0);
$user_id = getCurrentUser()['id'];
$existing = fetchOne("SELECT id FROM wishlist WHERE user_id=? AND food_id=?", 'ii', $user_id, $food_id);
if ($existing) {
    query("DELETE FROM wishlist WHERE user_id=? AND food_id=?", 'ii', $user_id, $food_id);
    echo json_encode(['success'=>true,'action'=>'removed']);
} else {
    query("INSERT IGNORE INTO wishlist (user_id, food_id) VALUES (?,?)", 'ii', $user_id, $food_id);
    echo json_encode(['success'=>true,'action'=>'added']);
}
