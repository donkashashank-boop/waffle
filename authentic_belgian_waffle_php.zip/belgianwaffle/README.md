# 🧇 Authentic Belgian Waffle — PHP + MySQL Project

A full-stack food ordering website for a college short-term project.

## 📁 Folder Structure
```
belgianwaffle/
├── index.php              ← Homepage
├── database.sql           ← MySQL schema + seed data
├── includes/
│   ├── config.php         ← DB connection & helpers
│   ├── auth.php           ← Session & auth helpers
│   ├── header.php         ← Navbar partial
│   └── footer.php         ← Footer + chatbot partial
├── pages/
│   ├── menu.php           ← Browse & filter menu
│   ├── cart.php           ← Shopping cart
│   ├── checkout.php       ← Payment page
│   ├── order_success.php  ← Order confirmation
│   ├── orders.php         ← My orders
│   ├── wishlist.php       ← Saved items
│   ├── recipes.php        ← Recipe guides
│   ├── about.php          ← About us
│   ├── contact.php        ← Contact form
│   ├── login.php          ← User login
│   └── register.php       ← User registration
├── admin/
│   └── index.php          ← Admin panel
├── api/
│   ├── cart.php           ← Cart add/update/remove
│   ├── order.php          ← Place order
│   ├── wishlist.php       ← Toggle wishlist (AJAX)
│   ├── admin.php          ← Admin AJAX actions
│   └── logout.php         ← Logout
└── assets/
    ├── css/style.css      ← Full stylesheet
    └── js/main.js         ← Theme, chatbot, AJAX
```

## ⚙️ Setup Instructions

### Requirements
- PHP 8.0+
- MySQL 5.7+ or MariaDB
- Apache/Nginx (or XAMPP/WAMP/Laragon)

### Step 1 — Import Database
```bash
mysql -u root -p < database.sql
```
Or import via phpMyAdmin → Import → select `database.sql`.

### Step 2 — Configure Database
Edit `includes/config.php`:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');       // your MySQL username
define('DB_PASS', '');           // your MySQL password
define('DB_NAME', 'belgian_waffle');
define('SITE_URL', 'http://localhost/belgianwaffle');
```

### Step 3 — Place in Web Root
Copy the `belgianwaffle/` folder into:
- **XAMPP**: `C:/xampp/htdocs/belgianwaffle`
- **WAMP**: `C:/wamp64/www/belgianwaffle`
- **Laragon**: `C:/laragon/www/belgianwaffle`

### Step 4 — Open in Browser
```
http://localhost/belgianwaffle
```

## 🔐 Admin Login
| Email | Password |
|-------|----------|
| admin@belgianwaffle.in | admin123 |

## ✨ Features
- 🧇 32 menu items across 6 categories
- 🛒 Session-based cart (works for guests too)
- 👤 User registration & login (bcrypt passwords)
- ❤️ Wishlist (per user, stored in MySQL)
- 📦 Order placement & order history
- ⚙️ Admin panel — add/delete/toggle food items
- 📬 Contact form saved to database
- 🌙 Dark/Light mode toggle
- 🤖 WaffleBot chatbot (JavaScript rule-based)
- 🍳 Recipe section from MySQL
- 📱 Fully responsive design
- 💳 Demo payment page (UPI/Card/COD)

## 🗄️ Database Tables
- `users` — registered users
- `categories` — 6 food categories
- `food_items` — 32 menu items
- `orders` — customer orders
- `cart` — session-based cart
- `wishlist` — user saved items
- `contact_messages` — contact form submissions
- `recipes` — recipe guides

## 🚀 Tech Stack
| Layer | Technology |
|-------|-----------|
| Frontend | HTML5, CSS3, JavaScript |
| Backend | PHP 8.0+ |
| Database | MySQL |
| Icons | Font Awesome 6 |
| Fonts | Google Fonts (Playfair Display + DM Sans) |

## 💡 Future Improvements
1. Email notifications via PHPMailer
2. Razorpay/PayU real payment integration
3. Image upload for food items
4. Real-time order tracking
5. Customer ratings & reviews
6. Promo codes & discounts
7. PDF invoice generation
