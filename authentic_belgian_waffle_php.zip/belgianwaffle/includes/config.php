<?php
/**
 * Database Configuration — Authentic Belgian Waffle
 * Edit the constants below to match your MySQL server.
 */

define('DB_HOST', 'localhost');
define('DB_USER', 'root');          // your MySQL username
define('DB_PASS', '');              // your MySQL password
define('DB_NAME', 'belgian_waffle');
define('DB_CHARSET', 'utf8mb4');
define('SITE_NAME', 'Authentic Belgian Waffle');
define('SITE_URL', 'http://localhost/belgianwaffle');
define('GST_RATE', 0.05);          // 5% GST

/**
 * Returns a MySQLi connection (singleton pattern).
 */
function db(): mysqli {
    static $conn = null;
    if ($conn === null) {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($conn->connect_error) {
            die(json_encode([
                'success' => false,
                'message' => 'Database connection failed: ' . $conn->connect_error
            ]));
        }
        $conn->set_charset(DB_CHARSET);
    }
    return $conn;
}

/**
 * Safe query helper — returns result or false.
 */
function query(string $sql, string $types = '', ...$params) {
    $db = db();
    $stmt = $db->prepare($sql);
    if (!$stmt) return false;
    if ($types && $params) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    return $stmt;
}

/**
 * Fetch all rows as associative array.
 */
function fetchAll(string $sql, string $types = '', ...$params): array {
    $stmt = query($sql, $types, ...$params);
    if (!$stmt) return [];
    $result = $stmt->get_result();
    return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
}

/**
 * Fetch a single row.
 */
function fetchOne(string $sql, string $types = '', ...$params): ?array {
    $stmt = query($sql, $types, ...$params);
    if (!$stmt) return null;
    $result = $stmt->get_result();
    return $result ? $result->fetch_assoc() : null;
}

/**
 * JSON response helper for API endpoints.
 */
function jsonResponse(array $data, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

/**
 * Sanitise user input.
 */
function clean(string $input): string {
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}
