<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';

// Cart count for nav badge
$cartCount = 0;
if (isLoggedIn()) {
    $row = fetchOne("SELECT SUM(quantity) AS total FROM cart WHERE session_id = ?", 's', getCartSessionId());
    $cartCount = (int)($row['total'] ?? 0);
}
$user = getCurrentUser();

// Active page detection
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title><?= $pageTitle ?? SITE_NAME ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;0,900;1,700&family=DM+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
    <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css"/>
    <?= $extraCss ?? '' ?>
</head>
<body>

<!-- Announcement Bar -->
<div class="announce">
    🎉 Grand Opening — Free Waffle on orders above ₹399 &nbsp;|&nbsp; Use code: <strong>WAFFLE50</strong>
</div>

<!-- Navbar -->
<nav class="navbar" id="navbar">
    <div class="nav-container">
        <a href="<?= SITE_URL ?>/index.php" class="nav-logo">
            <span class="logo-waffle">🧇</span>
            <span>Authentic <span class="accent">Belgian Waffle</span></span>
        </a>

        <ul class="nav-links" id="navLinks">
            <li><a href="<?= SITE_URL ?>/index.php"              class="nav-link <?= $currentPage === 'index'   ? 'active' : '' ?>">Home</a></li>
            <li><a href="<?= SITE_URL ?>/pages/menu.php"         class="nav-link <?= $currentPage === 'menu'    ? 'active' : '' ?>">Menu</a></li>
            <li><a href="<?= SITE_URL ?>/pages/recipes.php"      class="nav-link <?= $currentPage === 'recipes' ? 'active' : '' ?>">Recipes</a></li>
            <li><a href="<?= SITE_URL ?>/pages/about.php"        class="nav-link <?= $currentPage === 'about'   ? 'active' : '' ?>">About</a></li>
            <li><a href="<?= SITE_URL ?>/pages/contact.php"      class="nav-link <?= $currentPage === 'contact' ? 'active' : '' ?>">Contact</a></li>
        </ul>

        <div class="nav-actions">
            <!-- Dark Mode -->
            <button class="icon-btn" id="themeBtn" title="Toggle theme">
                <i class="fas fa-moon" id="themeIco"></i>
            </button>

            <!-- Cart -->
            <a href="<?= SITE_URL ?>/pages/cart.php" class="icon-btn" title="Cart">
                <i class="fas fa-shopping-basket"></i>
                <span class="cart-badge" id="cartBadge"><?= $cartCount ?></span>
            </a>

            <!-- User -->
            <?php if ($user): ?>
            <div class="user-menu">
                <button class="user-btn">
                    <i class="fas fa-user-circle"></i>
                    <span><?= htmlspecialchars(explode(' ', $user['name'])[0]) ?></span>
                    <i class="fas fa-chevron-down" style="font-size:.7rem"></i>
                </button>
                <div class="user-dropdown">
                    <?php if ($user['is_admin']): ?>
                    <a href="<?= SITE_URL ?>/admin/index.php"><i class="fas fa-cog"></i> Admin Panel</a>
                    <?php endif; ?>
                    <a href="<?= SITE_URL ?>/pages/orders.php"><i class="fas fa-box"></i> My Orders</a>
                    <a href="<?= SITE_URL ?>/pages/wishlist.php"><i class="fas fa-heart"></i> Wishlist</a>
                    <a href="<?= SITE_URL ?>/api/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>
            <?php else: ?>
            <a href="<?= SITE_URL ?>/pages/login.php"    class="btn btn-outline btn-sm">Login</a>
            <a href="<?= SITE_URL ?>/pages/register.php" class="btn btn-gold btn-sm">Sign Up</a>
            <?php endif; ?>

            <button class="hamburger" id="hamburger">
                <span></span><span></span><span></span>
            </button>
        </div>
    </div>
</nav>
