<?php /* Footer partial */ ?>

<!-- Chatbot -->
<div class="chatbot-wrap">
    <button class="chat-toggle" id="chatToggle">
        <i class="fas fa-comment-dots"></i>
        <span class="chat-badge-ai">AI</span>
    </button>
    <div class="chat-box" id="chatBox">
        <div class="chat-head">
            <div class="chat-av">🧇</div>
            <div><strong>WaffleBot</strong><small>Your waffle assistant</small></div>
            <button class="chat-close" id="chatClose"><i class="fas fa-times"></i></button>
        </div>
        <div class="chat-msgs" id="chatMsgs">
            <div class="bot-msg">👋 Hi! I'm WaffleBot. Ask me about our waffles, ice creams, pancakes, milkshakes, waffle cakes or brownies!</div>
        </div>
        <div class="chat-input-row">
            <input type="text" id="chatIn" placeholder="Ask for suggestions..."/>
            <button id="chatSend"><i class="fas fa-paper-plane"></i></button>
        </div>
    </div>
</div>

<!-- Toast Container -->
<div class="toast-wrap" id="toastWrap"></div>

<!-- Footer -->
<footer class="footer">
    <div class="footer-grid">
        <div class="footer-brand">
            <a href="<?= SITE_URL ?>/index.php" class="nav-logo" style="color:#fff;margin-bottom:1rem;display:inline-flex;">
                🧇 Authentic <span class="accent" style="margin-left:.3rem">Belgian Waffle</span>
            </a>
            <p>Handcrafted Belgian waffles, ice creams, fluffy pancakes, thick milkshakes, waffle cakes & fudgy brownies — delivered with love.</p>
            <div class="socials">
                <a href="#" class="social-a"><i class="fab fa-facebook-f"></i></a>
                <a href="#" class="social-a"><i class="fab fa-instagram"></i></a>
                <a href="#" class="social-a"><i class="fab fa-twitter"></i></a>
                <a href="#" class="social-a"><i class="fab fa-youtube"></i></a>
            </div>
        </div>
        <div class="footer-col">
            <h4>Quick Links</h4>
            <ul>
                <li><a href="<?= SITE_URL ?>/index.php">Home</a></li>
                <li><a href="<?= SITE_URL ?>/pages/menu.php">Menu</a></li>
                <li><a href="<?= SITE_URL ?>/pages/recipes.php">Recipes</a></li>
                <li><a href="<?= SITE_URL ?>/pages/about.php">About</a></li>
                <li><a href="<?= SITE_URL ?>/pages/contact.php">Contact</a></li>
            </ul>
        </div>
        <div class="footer-col">
            <h4>Our Specialties</h4>
            <ul>
                <li><a href="<?= SITE_URL ?>/pages/menu.php?cat=waffles">🧇 Waffles</a></li>
                <li><a href="<?= SITE_URL ?>/pages/menu.php?cat=ice_cream">🍦 Ice Creams</a></li>
                <li><a href="<?= SITE_URL ?>/pages/menu.php?cat=pancakes">🥞 Pancakes</a></li>
                <li><a href="<?= SITE_URL ?>/pages/menu.php?cat=milkshakes">🥤 Milkshakes</a></li>
                <li><a href="<?= SITE_URL ?>/pages/menu.php?cat=waffle_cakes">🎂 Waffle Cakes</a></li>
                <li><a href="<?= SITE_URL ?>/pages/menu.php?cat=brownies">🍫 Brownies</a></li>
            </ul>
        </div>
        <div class="footer-col">
            <h4>Contact</h4>
            <ul>
                <li><i class="fas fa-map-marker-alt"></i> Hyderabad, India</li>
                <li><i class="fas fa-phone"></i> +91 98765 43210</li>
                <li><i class="fas fa-envelope"></i> hello@belgianwaffle.in</li>
                <li><i class="fas fa-clock"></i> 9AM – 11PM Daily</li>
            </ul>
        </div>
    </div>
    <div class="footer-bottom">
        <p>© <?= date('Y') ?> Authentic Belgian Waffle. Built with ❤️ using PHP + MySQL.</p>
        <p>HTML · CSS · PHP · MySQL</p>
    </div>
</footer>

<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
<?= $extraJs ?? '' ?>
</body>
</html>
