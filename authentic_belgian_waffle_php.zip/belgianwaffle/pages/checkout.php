<?php
$pageTitle = 'Checkout — Authentic Belgian Waffle';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
$sid   = getCartSessionId();
$items = fetchAll("SELECT c.id AS cart_id, c.quantity, f.id AS food_id, f.name, f.price, cat.emoji FROM cart c JOIN food_items f ON c.food_id=f.id JOIN categories cat ON f.category_id=cat.id WHERE c.session_id=?", 's', $sid);
if (empty($items)) { header('Location: ' . SITE_URL . '/pages/cart.php'); exit; }
$subtotal = array_sum(array_map(fn($i)=>$i['price']*$i['quantity'], $items));
$gst = round($subtotal * 0.05, 2);
$total = $subtotal + $gst;
$user = getCurrentUser();
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-hero"><div class="container"><h1>💳 <span class="accent">Checkout</span></h1><p>Almost there — secure demo payment</p></div></div>
<section class="section"><div class="container" style="max-width:640px">
  <div class="pay-card">
    <div style="text-align:center;margin-bottom:1.5rem"><span style="background:#D1FAE5;color:#065F46;font-size:.78rem;font-weight:700;padding:.3rem .9rem;border-radius:var(--rpill)">🔒 100% Secure</span><h3 style="font-family:'Playfair Display',serif;font-weight:700;margin-top:.6rem">Choose Payment Method</h3></div>
    <div class="pay-methods">
      <button class="pay-tab active" onclick="selPay(this,'upi')"><i class="fas fa-mobile-alt"></i> UPI</button>
      <button class="pay-tab" onclick="selPay(this,'card')"><i class="fas fa-credit-card"></i> Card</button>
      <button class="pay-tab" onclick="selPay(this,'cod')"><i class="fas fa-money-bill-wave"></i> Cash</button>
    </div>
    <div id="upiSection">
      <div class="form-group"><label>UPI ID</label><input type="text" placeholder="yourname@upi"/></div>
      <div class="upi-apps"><span class="upi-pill">PhonePe</span><span class="upi-pill">Google Pay</span><span class="upi-pill">Paytm</span></div>
    </div>
    <div id="cardSection" style="display:none">
      <div class="form-group"><label>Card Number</label><input type="text" placeholder="1234 5678 9012 3456" maxlength="19"/></div>
      <div class="form-row"><div class="form-group"><label>Expiry</label><input type="text" placeholder="MM/YY"/></div><div class="form-group"><label>CVV</label><input type="text" placeholder="•••" maxlength="3"/></div></div>
      <div class="form-group"><label>Name on Card</label><input type="text" placeholder="Your Name"/></div>
    </div>
    <div id="codSection" style="display:none"><div class="cod-box"><i class="fas fa-truck"></i><p>Pay cash when your order arrives. No extra charge!</p></div></div>
    <div style="margin:1rem 0;padding:1rem;background:var(--cream2);border-radius:var(--r);font-size:.88rem">
      <strong>Order Total: Rs.<?= number_format($total,2) ?></strong> (<?= count($items) ?> item<?= count($items)!==1?'s':'' ?>)
    </div>
    <form action="<?= SITE_URL ?>/api/order.php" method="POST" id="orderForm">
      <input type="hidden" name="subtotal" value="<?= $subtotal ?>"/>
      <input type="hidden" name="gst" value="<?= $gst ?>"/>
      <input type="hidden" name="total" value="<?= $total ?>"/>
      <input type="hidden" name="payment_method" id="payMethod" value="upi"/>
      <div class="form-group"><label>Delivery Address</label><textarea name="address" rows="3" placeholder="Full delivery address..." required></textarea></div>
      <?php if (!$user): ?>
      <div class="form-row">
        <div class="form-group"><label>Your Name</label><input type="text" name="customer_name" placeholder="Full Name" required/></div>
        <div class="form-group"><label>Email</label><input type="email" name="customer_email" placeholder="Email" required/></div>
      </div>
      <?php endif; ?>
      <button type="submit" class="btn btn-gold btn-full" onclick="this.disabled=true;this.innerHTML='<i class=\'fas fa-spinner fa-spin\'></i> Processing...'"><i class="fas fa-check-circle"></i> Confirm &amp; Place Order</button>
    </form>
    <p style="text-align:center;color:var(--text3);font-size:.78rem;margin-top:1rem"><i class="fas fa-shield-alt"></i> Demo only — no real transactions occur.</p>
  </div>
</div></section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
<script>const BASE_URL = '<?= SITE_URL ?>';
document.querySelectorAll('.pay-tab').forEach(b=>b.addEventListener('click',function(){document.getElementById('payMethod').value=this.textContent.trim().toLowerCase().includes('upi')?'upi':this.textContent.trim().toLowerCase().includes('card')?'card':'cod';}));</script>
