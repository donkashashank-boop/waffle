<?php
$pageTitle = 'Recipes — Authentic Belgian Waffle';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
$recipes = fetchAll("SELECT * FROM recipes ORDER BY id");
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-hero"><div class="container"><h1>🧇 <span class="accent">Recipes</span></h1><p>Make our signature treats at home — step by step</p></div></div>
<section class="section"><div class="container"><div class="recipe-grid">
<?php foreach ($recipes as $r):
  $ingredients = json_decode($r['ingredients'], true) ?? [];
  $steps       = json_decode($r['steps'], true) ?? [];
  $tagColors   = ['waffles'=>'background:#FEF3C7;color:#92400E','milkshakes'=>'background:#D1FAE5;color:#065F46','brownies'=>'background:#FEF3C7;color:#78350F','pancakes'=>'background:#FCE7F3;color:#9D174D'];
  $tagStyle    = $tagColors[$r['category']] ?? 'background:#E0F2FE;color:#0369A1';
?>
<div class="recipe-card">
  <div class="recipe-hero"><?= $r['emoji'] ?></div>
  <div class="recipe-body">
    <span class="recipe-tag" style="<?= $tagStyle ?>"><?= ucfirst($r['category']) ?></span>
    <h3><?= htmlspecialchars($r['title']) ?></h3>
    <p><?= htmlspecialchars($r['description']) ?></p>
    <div class="recipe-meta">
      <span><i class="fas fa-clock"></i> <?= $r['prep_time'] ?> min</span>
      <span><i class="fas fa-signal"></i> <?= $r['difficulty'] ?></span>
      <span><i class="fas fa-users"></i> <?= $r['servings'] ?> servings</span>
    </div>
    <div class="recipe-steps">
      <h4>Ingredients</h4>
      <ul><?php foreach ($ingredients as $ing): ?><li><?= htmlspecialchars($ing) ?></li><?php endforeach; ?></ul>
      <h4>Steps</h4>
      <ol><?php foreach ($steps as $step): ?><li><?= htmlspecialchars($step) ?></li><?php endforeach; ?></ol>
    </div>
  </div>
</div>
<?php endforeach; ?>
</div></div></section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
<script>const BASE_URL = '<?= SITE_URL ?>';</script>
