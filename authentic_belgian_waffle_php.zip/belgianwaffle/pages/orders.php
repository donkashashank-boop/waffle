<?php
$pageTitle = 'My Orders — Authentic Belgian Waffle';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
requireLogin();
$user   = getCurrentUser();
$orders = fetchAll("SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC", 'i', $user['id']);
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-hero"><div class="container"><h1>📦 My <span class="accent">Orders</span></h1><p>Track all your past orders</p></div></div>
<section class="section"><div class="container">
<?php if (empty($orders)): ?>
  <div class="empty-state"><div class="empty-icon">📦</div><h3>No orders yet</h3><p>Your order history will appear here after your first purchase.</p><br/><a href="<?= SITE_URL ?>/pages/menu.php" class="btn btn-gold">Browse Menu</a></div>
<?php else: foreach ($orders as $o):
  $items = json_decode($o['items_json'], true) ?? [];
?>
  <div class="order-card">
    <div class="order-header">
      <div><div class="order-id">Order #<?= $o['id'] ?></div><div class="order-date"><?= date('d M Y, h:i A', strtotime($o['created_at'])) ?></div></div>
      <span class="status-badge status-<?= $o['status'] ?>"><?= ucfirst($o['status']) ?></span>
    </div>
    <div class="order-items"><?= implode(', ', array_map(fn($i)=>htmlspecialchars($i['name']).' x'.$i['quantity'], $items)) ?></div>
    <div class="order-footer"><span><?= htmlspecialchars($o['delivery_address']) ?></span><span class="order-total">Rs.<?= number_format($o['total'],2) ?></span></div>
  </div>
<?php endforeach; endif; ?>
</div></section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
<script>const BASE_URL = '<?= SITE_URL ?>';</script>
