<?php
$pageTitle = 'Login — Authentic Belgian Waffle';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
if (isLoggedIn()) { header('Location: ' . SITE_URL); exit; }
$error = ''; $success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = clean($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';
    $user  = fetchOne("SELECT * FROM users WHERE email = ?", 's', $email);
    if ($user && password_verify($pass, $user['password'])) {
        loginUser($user);
        header('Location: ' . SITE_URL . '/index.php'); exit;
    } else { $error = 'Invalid email or password.'; }
}
require_once __DIR__ . '/../includes/header.php';
?>
<div class="auth-page"><div class="auth-card">
  <div class="auth-header"><div class="auth-logo">🧇</div><h2>Welcome Back!</h2><p>Login to your account</p></div>
  <?php if ($error): ?><div class="alert alert-error"><?= $error ?></div><?php endif; ?>
  <form method="POST">
    <div class="form-group"><label>Email</label><input type="email" name="email" placeholder="you@example.com" required/></div>
    <div class="form-group"><label>Password</label><input type="password" name="password" placeholder="Your password" required/></div>
    <button type="submit" class="btn btn-gold btn-full"><i class="fas fa-sign-in-alt"></i> Login</button>
  </form>
  <div class="alert alert-info" style="margin-top:1rem;font-size:.82rem;">Demo Admin: <strong>admin@belgianwaffle.in</strong> / <strong>admin123</strong></div>
  <p style="text-align:center;margin-top:1rem;font-size:.88rem;color:var(--text3)">No account? <a href="<?= SITE_URL ?>/pages/register.php" style="color:var(--gold);font-weight:600">Sign Up Free</a></p>
</div></div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
<script>const BASE_URL = '<?= SITE_URL ?>';</script>
