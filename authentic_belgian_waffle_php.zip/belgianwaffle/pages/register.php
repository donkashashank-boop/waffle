<?php
$pageTitle = 'Register — Authentic Belgian Waffle';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
if (isLoggedIn()) { header('Location: ' . SITE_URL); exit; }
$error = ''; $success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name  = clean($_POST['name']  ?? '');
    $email = clean($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';
    $phone = clean($_POST['phone'] ?? '');
    if (strlen($pass) < 6) { $error = 'Password must be at least 6 characters.'; }
    elseif (fetchOne("SELECT id FROM users WHERE email=?", 's', $email)) { $error = 'Email already registered.'; }
    else {
        $hash = password_hash($pass, PASSWORD_BCRYPT);
        query("INSERT INTO users (name, email, password, phone) VALUES (?,?,?,?)", 'ssss', $name, $email, $hash, $phone);
        $user = fetchOne("SELECT * FROM users WHERE email=?", 's', $email);
        loginUser($user);
        header('Location: ' . SITE_URL . '/index.php'); exit;
    }
}
require_once __DIR__ . '/../includes/header.php';
?>
<div class="auth-page"><div class="auth-card">
  <div class="auth-header"><div class="auth-logo">🧇</div><h2>Join Us!</h2><p>Create your free account today</p></div>
  <?php if ($error): ?><div class="alert alert-error"><?= $error ?></div><?php endif; ?>
  <form method="POST">
    <div class="form-group"><label>Full Name</label><input type="text" name="name" placeholder="Your full name" required/></div>
    <div class="form-group"><label>Email</label><input type="email" name="email" placeholder="you@example.com" required/></div>
    <div class="form-group"><label>Phone</label><input type="tel" name="phone" placeholder="+91 98765 43210"/></div>
    <div class="form-group"><label>Password</label><input type="password" name="password" placeholder="Min. 6 characters" required minlength="6"/></div>
    <button type="submit" class="btn btn-gold btn-full"><i class="fas fa-user-plus"></i> Create Account</button>
  </form>
  <p style="text-align:center;margin-top:1rem;font-size:.88rem;color:var(--text3)">Already have an account? <a href="<?= SITE_URL ?>/pages/login.php" style="color:var(--gold);font-weight:600">Login</a></p>
</div></div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
<script>const BASE_URL = '<?= SITE_URL ?>';</script>
