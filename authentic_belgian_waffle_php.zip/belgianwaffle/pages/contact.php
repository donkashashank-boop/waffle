<?php
$pageTitle = 'Contact — Authentic Belgian Waffle';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
$success = ''; $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = clean($_POST['name'] ?? ''); $email = clean($_POST['email'] ?? ''); $msg = clean($_POST['message'] ?? '');
    if ($name && $email && $msg) {
        query("INSERT INTO contact_messages (name, email, message) VALUES (?,?,?)", 'sss', $name, $email, $msg);
        $success = "Message sent! We'll get back to you soon. 😊";
    } else { $error = 'Please fill in all fields.'; }
}
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-hero"><div class="container"><h1>Get in <span class="accent">Touch</span></h1><p>We'd love to hear from you!</p></div></div>
<section class="section"><div class="container"><div class="contact-grid">
  <div>
    <h3 style="font-family:'Playfair Display',serif;font-weight:700;margin-bottom:1.5rem;font-size:1.2rem;">Contact Info</h3>
    <div class="cinfo"><div class="cinfo-icon"><i class="fas fa-map-marker-alt"></i></div><div><strong>Address</strong><p>42 Waffle Street, Jubilee Hills, Hyderabad</p></div></div>
    <div class="cinfo"><div class="cinfo-icon"><i class="fas fa-phone"></i></div><div><strong>Phone</strong><p>+91 98765 43210</p></div></div>
    <div class="cinfo"><div class="cinfo-icon"><i class="fas fa-envelope"></i></div><div><strong>Email</strong><p>hello@belgianwaffle.in</p></div></div>
    <div class="cinfo"><div class="cinfo-icon"><i class="fas fa-clock"></i></div><div><strong>Hours</strong><p>Mon–Sun: 9AM – 11PM</p></div></div>
  </div>
  <div>
    <h3 style="font-family:'Playfair Display',serif;font-weight:700;margin-bottom:1.25rem;font-size:1.2rem;">Send a Message</h3>
    <?php if ($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>
    <?php if ($error):   ?><div class="alert alert-error"><?= $error ?></div><?php endif; ?>
    <form method="POST">
      <div class="form-row">
        <div class="form-group"><label>Name</label><input type="text" name="name" placeholder="Your name" required/></div>
        <div class="form-group"><label>Email</label><input type="email" name="email" placeholder="you@email.com" required/></div>
      </div>
      <div class="form-group"><label>Message</label><textarea name="message" rows="5" placeholder="How can we help?" required></textarea></div>
      <button type="submit" class="btn btn-gold"><i class="fas fa-paper-plane"></i> Send Message</button>
    </form>
  </div>
</div></div></section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
<script>const BASE_URL = '<?= SITE_URL ?>';</script>
