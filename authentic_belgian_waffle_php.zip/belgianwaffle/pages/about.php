<?php
$pageTitle = 'About — Authentic Belgian Waffle';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
$foodCount  = fetchOne("SELECT COUNT(*) AS n FROM food_items WHERE is_available=1")['n'];
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-hero"><div class="container"><h1>About <span class="accent">Authentic Belgian Waffle</span></h1><p>Our story, our passion, our craft</p></div></div>
<section class="section"><div class="container"><div class="about-grid">
  <div class="about-text">
    <h2>Born from a <span class="accent">Love for Waffles</span></h2>
    <p>Authentic Belgian Waffle was founded in 2024 with one simple mission — to bring the true taste of handcrafted Belgian waffles to India. Every waffle, pancake, brownie, and milkshake we make uses premium ingredients and traditional Belgian techniques.</p>
    <p>From our signature crispy-edged Belgian waffles to decadent multi-layer waffle cakes, every item on our menu is crafted fresh to order. We believe dessert is an experience worth savouring.</p>
    <div class="about-stats">
      <div class="astat"><strong><?= $foodCount ?>+</strong><span>Menu Items</span></div>
      <div class="astat"><strong>10k+</strong><span>Happy Guests</span></div>
      <div class="astat"><strong>4.9★</strong><span>Avg. Rating</span></div>
    </div>
  </div>
  <div>
    <h3 style="font-family:'Playfair Display',serif;font-weight:700;margin-bottom:1.25rem;font-size:1.2rem;">Our Promises</h3>
    <div class="value-card"><span>🧇</span><div><strong>Authentic Recipes</strong><p>True Belgian waffle recipes using premium European-style ingredients.</p></div></div>
    <div class="value-card"><span>🌿</span><div><strong>Fresh Daily</strong><p>Every batter is freshly prepared each morning — no frozen shortcuts ever.</p></div></div>
    <div class="value-card"><span>❤️</span><div><strong>Made with Love</strong><p>Each item is handcrafted with care, not mass-produced on a conveyor belt.</p></div></div>
    <div class="value-card"><span>⚡</span><div><strong>Fast Delivery</strong><p>Hot waffles and cold ice cream — perfectly timed to your door in 30 min.</p></div></div>
  </div>
</div></div></section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
<script>const BASE_URL = '<?= SITE_URL ?>';</script>
