<?php
$pageTitle = 'Order Placed — Authentic Belgian Waffle';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/header.php';
?>
<section class="section"><div class="container" style="max-width:600px;text-align:center;padding:5rem 1.5rem">
  <div style="font-size:5rem;margin-bottom:1.5rem">🎉</div>
  <h2 style="font-family:'Playfair Display',serif;font-size:2rem;font-weight:900;margin-bottom:1rem">Order Placed Successfully!</h2>
  <p style="color:var(--text2);margin-bottom:2rem;font-size:1.05rem">Your delicious order is being prepared. Estimated delivery time: <strong>30 minutes</strong>. 🧇</p>
  <a href="<?= SITE_URL ?>/index.php" class="btn btn-gold btn-lg"><i class="fas fa-home"></i> Back to Home</a>
  <a href="<?= SITE_URL ?>/pages/menu.php" class="btn btn-outline btn-lg" style="margin-left:.75rem"><i class="fas fa-utensils"></i> Order More</a>
</div></section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
<script>const BASE_URL = '<?= SITE_URL ?>';</script>
