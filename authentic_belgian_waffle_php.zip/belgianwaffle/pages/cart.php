<?php
$pageTitle = 'My Cart — Authentic Belgian Waffle';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
$sid = getCartSessionId();
$items = fetchAll("SELECT c.id AS cart_id, c.quantity, f.id AS food_id, f.name, f.price, cat.emoji FROM cart c JOIN food_items f ON c.food_id=f.id JOIN categories cat ON f.category_id=cat.id WHERE c.session_id=?", 's', $sid);
$subtotal = array_sum(array_map(fn($i)=>$i['price']*$i['quantity'], $items));
$gst = round($subtotal * 0.05, 2);
$total = $subtotal + $gst;
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-hero"><div class="container"><h1>🛒 My <span class="accent">Cart</span></h1><p>Review your order before checkout</p></div></div>
<section class="section"><div class="container">
<?php if (isset($_GET['msg'])): ?><div class="alert alert-success"><?= htmlspecialchars($_GET['msg']) ?></div><?php endif; ?>
<div class="cart-layout">
  <div>
    <?php if (empty($items)): ?>
      <div class="empty-state"><div class="empty-icon">🛒</div><h3>Your cart is empty</h3><p>Add some delicious items from our menu!</p><br/><a href="<?= SITE_URL ?>/pages/menu.php" class="btn btn-gold">Browse Menu</a></div>
    <?php else: foreach ($items as $i): ?>
    <div class="cart-item">
      <div class="cart-emoji"><?= $i['emoji'] ?></div>
      <div class="cart-info"><h4><?= htmlspecialchars($i['name']) ?></h4><p>Rs.<?= number_format($i['price'],0) ?> each</p></div>
      <form class="qty-form" action="<?= SITE_URL ?>/api/cart.php" method="POST">
        <input type="hidden" name="action" value="update"/>
        <input type="hidden" name="cart_id" value="<?= $i['cart_id'] ?>"/>
        <button type="submit" name="delta" value="-1">−</button>
        <input type="number" name="quantity" value="<?= $i['quantity'] ?>" min="1" max="20" id="qty-<?= $i['cart_id'] ?>"/>
        <button type="submit" name="delta" value="1">+</button>
      </form>
      <div class="cart-item-total" id="item-total-<?= $i['cart_id'] ?>">Rs.<?= number_format($i['price']*$i['quantity'],0) ?></div>
      <form action="<?= SITE_URL ?>/api/cart.php" method="POST" style="display:inline">
        <input type="hidden" name="action" value="remove"/>
        <input type="hidden" name="cart_id" value="<?= $i['cart_id'] ?>"/>
        <button type="submit" class="rm-btn"><i class="fas fa-trash"></i></button>
      </form>
    </div>
    <?php endforeach; endif; ?>
  </div>
  <div class="summary-card">
    <h3>Order Summary</h3>
    <div class="sum-row"><span>Subtotal</span><span id="cart-subtotal">Rs.<?= number_format($subtotal,0) ?></span></div>
    <div class="sum-row"><span>Delivery</span><span class="green">FREE</span></div>
    <div class="sum-row"><span>GST (5%)</span><span id="cart-gst">Rs.<?= number_format($gst,0) ?></span></div>
    <div class="sum-row total"><span>Total</span><span id="cart-total">Rs.<?= number_format($total,0) ?></span></div>
    <br/>
    <div class="form-group"><label><i class="fas fa-map-marker-alt"></i> Delivery Address</label><textarea name="address" id="delivAddr" rows="3" placeholder="Enter your full address..."></textarea></div>
    <?php if (!empty($items)): ?>
    <a href="<?= SITE_URL ?>/pages/checkout.php" class="btn btn-gold btn-full"><i class="fas fa-credit-card"></i> Proceed to Payment</a>
    <?php endif; ?>
    <br/><br/>
    <a href="<?= SITE_URL ?>/pages/menu.php" class="btn btn-outline btn-full"><i class="fas fa-arrow-left"></i> Continue Shopping</a>
  </div>
</div>
</div></section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
<script>const BASE_URL = '<?= SITE_URL ?>';</script>
