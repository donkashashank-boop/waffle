<?php
$pageTitle = 'Wishlist — Authentic Belgian Waffle';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
requireLogin();
$user  = getCurrentUser();
$foods = fetchAll("SELECT f.*, c.slug AS cat_slug, c.emoji AS cat_emoji, c.name AS cat_name FROM wishlist w JOIN food_items f ON w.food_id=f.id JOIN categories c ON f.category_id=c.id WHERE w.user_id=?", 'i', $user['id']);
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-hero"><div class="container"><h1>❤️ My <span class="accent">Wishlist</span></h1><p>Your saved favourites</p></div></div>
<section class="section"><div class="container">
<?php if (empty($foods)): ?>
  <div class="empty-state"><div class="empty-icon">❤️</div><h3>Wishlist is empty</h3><p>Tap the 🤍 on any food item to save it here.</p><br/><a href="<?= SITE_URL ?>/pages/menu.php" class="btn btn-gold">Browse Menu</a></div>
<?php else: ?>
  <div class="food-grid">
  <?php foreach ($foods as $f): ?>
    <div class="food-card">
      <div class="food-img"><?= $f['cat_emoji'] ?></div>
      <div class="food-body">
        <span class="cat-pill pill-<?= $f['cat_slug'] ?>"><?= htmlspecialchars($f['cat_name']) ?></span>
        <div class="food-top"><h3 class="food-name"><?= htmlspecialchars($f['name']) ?></h3>
          <button class="wish-btn" onclick="toggleWish(<?= $f['id'] ?>,this)">❤️</button></div>
        <p class="food-desc"><?= htmlspecialchars($f['description']) ?></p>
        <div class="food-footer"><span class="food-price">Rs.<?= number_format($f['price'],0) ?></span><span class="food-rating"><span class="star-gold">★</span> <?= $f['rating'] ?></span></div>
        <form class="atc-form" action="<?= SITE_URL ?>/api/cart.php" method="POST">
          <input type="hidden" name="action" value="add"/><input type="hidden" name="food_id" value="<?= $f['id'] ?>"/>
          <input type="hidden" name="redirect" value="<?= SITE_URL ?>/pages/wishlist.php"/>
          <button type="submit"><i class="fas fa-plus"></i> Add to Cart</button>
        </form>
      </div>
    </div>
  <?php endforeach; ?>
  </div>
<?php endif; ?>
</div></section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
<script>const BASE_URL = '<?= SITE_URL ?>';</script>
