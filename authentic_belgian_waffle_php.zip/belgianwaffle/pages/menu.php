<?php
$pageTitle = 'Menu — Authentic Belgian Waffle';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
$cat    = clean($_GET['cat']    ?? '');
$search = clean($_GET['search'] ?? '');
$sql    = "SELECT f.*, c.slug AS cat_slug, c.emoji AS cat_emoji, c.name AS cat_name FROM food_items f JOIN categories c ON f.category_id = c.id WHERE f.is_available = 1";
$params = []; $types = '';
if ($cat)    { $sql .= " AND c.slug = ?"; $types .= 's'; $params[] = $cat; }
if ($search) { $sql .= " AND (f.name LIKE ? OR f.description LIKE ?)"; $types .= 'ss'; $params[] = "%$search%"; $params[] = "%$search%"; }
$sql .= " ORDER BY f.rating DESC";
$foods      = fetchAll($sql, $types, ...$params);
$categories = fetchAll("SELECT * FROM categories ORDER BY id");
$wishlist   = isLoggedIn() ? array_column(fetchAll("SELECT food_id FROM wishlist WHERE user_id=?", 'i', getCurrentUser()['id']), 'food_id') : [];
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-hero"><div class="container"><h1>Our <span class="accent">Menu</span></h1><p>32 freshly crafted items — find your favourite</p></div></div>
<section class="section"><div class="container">
  <form method="GET" class="search-row">
    <?php if ($cat): ?><input type="hidden" name="cat" value="<?= htmlspecialchars($cat) ?>"/><?php endif; ?>
    <div class="search-wrap"><i class="fas fa-search"></i><input type="text" name="search" placeholder="Search waffles, shakes, brownies..." value="<?= htmlspecialchars($search) ?>"/></div>
    <button type="submit" class="btn btn-gold btn-sm"><i class="fas fa-search"></i> Search</button>
    <?php if ($search || $cat): ?><a href="<?= SITE_URL ?>/pages/menu.php" class="btn btn-outline btn-sm">Clear</a><?php endif; ?>
  </form>
  <div class="cat-grid" style="margin-bottom:2rem">
    <a href="<?= SITE_URL ?>/pages/menu.php" class="cat-card <?= !$cat ? 'active-cat' : '' ?>"><div class="cat-emoji">🍽️</div><h3>All</h3><p>Everything</p></a>
    <?php foreach ($categories as $c): ?>
    <a href="<?= SITE_URL ?>/pages/menu.php?cat=<?= $c['slug'] ?>" class="cat-card <?= $cat===$c['slug'] ? 'active-cat' : '' ?>"><div class="cat-emoji"><?= $c['emoji'] ?></div><h3><?= htmlspecialchars($c['name']) ?></h3><p><?= htmlspecialchars($c['tagline']) ?></p></a>
    <?php endforeach; ?>
  </div>
  <p class="result-count"><?= count($foods) ?> item<?= count($foods)!==1?'s':'' ?> found</p>
  <?php if (isset($_GET['added'])): ?><div class="alert alert-success"><i class="fas fa-check-circle"></i> Item added to cart!</div><?php endif; ?>
  <div class="food-grid">
    <?php if (empty($foods)): ?>
      <div class="empty-state"><div class="empty-icon">🧇</div><h3>No items found</h3><p>Try a different category or search.</p></div>
    <?php else: foreach ($foods as $f): $wished = in_array($f['id'], $wishlist); ?>
    <div class="food-card">
      <div class="food-img"><?= $f['cat_emoji'] ?></div>
      <div class="food-body">
        <span class="cat-pill pill-<?= $f['cat_slug'] ?>"><?= htmlspecialchars($f['cat_name']) ?></span>
        <div class="food-top"><h3 class="food-name"><?= htmlspecialchars($f['name']) ?></h3>
          <button class="wish-btn" onclick="toggleWish(<?= $f['id'] ?>,this)"><?= $wished?'❤️':'🤍' ?></button></div>
        <p class="food-desc"><?= htmlspecialchars($f['description']) ?></p>
        <div class="food-footer"><span class="food-price">Rs.<?= number_format($f['price'],0) ?></span><span class="food-rating"><span class="star-gold">★</span> <?= $f['rating'] ?></span></div>
        <form class="atc-form" action="<?= SITE_URL ?>/api/cart.php" method="POST">
          <input type="hidden" name="action" value="add"/>
          <input type="hidden" name="food_id" value="<?= $f['id'] ?>"/>
          <input type="hidden" name="redirect" value="<?= SITE_URL ?>/pages/menu.php?cat=<?= urlencode($cat) ?>&added=1"/>
          <button type="submit"><i class="fas fa-plus"></i> Add to Cart</button>
        </form>
      </div>
    </div>
    <?php endforeach; endif; ?>
  </div>
</div></section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
<script>const BASE_URL = '<?= SITE_URL ?>';</script>
