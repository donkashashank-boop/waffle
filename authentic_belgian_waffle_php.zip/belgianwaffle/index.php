<?php
$pageTitle = 'Authentic Belgian Waffle — Home';
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';

// Fetch top 4 highest-rated foods for featured section
$featured = fetchAll("
    SELECT f.*, c.slug AS cat_slug, c.emoji AS cat_emoji, c.name AS cat_name
    FROM food_items f
    JOIN categories c ON f.category_id = c.id
    WHERE f.is_available = 1
    ORDER BY f.rating DESC LIMIT 4
");

// Fetch categories
$categories = fetchAll("SELECT * FROM categories ORDER BY id");
require_once __DIR__ . '/includes/header.php';
?>

<!-- Hero -->
<section class="hero">
  <div class="hero-pattern">
    <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%">
      <defs><pattern id="grid" width="60" height="60" patternUnits="userSpaceOnUse">
        <path d="M 60 0 L 0 0 0 60" fill="none" stroke="#C8922A" stroke-width="1"/>
      </pattern></defs>
      <rect width="100%" height="100%" fill="url(#grid)"/>
    </svg>
  </div>
  <div class="hero-glow"></div><div class="hero-glow2"></div>
  <div class="hero-container">
    <div class="hero-text">
      <div class="hero-tag"><i class="fas fa-award"></i> Belgium's Finest in India</div>
      <h1>Handcrafted<br/><span class="accent">Belgian Waffles</span><br/>&amp; More</h1>
      <p class="hero-sub">Crispy outside, cloud-soft inside. Topped your way — with ice cream, Nutella, fresh berries, or all three. Made fresh on every single order.</p>
      <div class="hero-actions">
        <a href="<?= SITE_URL ?>/pages/menu.php" class="btn btn-gold btn-lg"><i class="fas fa-utensils"></i> Explore Menu</a>
        <a href="<?= SITE_URL ?>/pages/recipes.php" class="btn btn-outline btn-lg"><i class="fas fa-book-open"></i> Recipes</a>
      </div>
      <div class="hero-trust">
        <div class="trust-item"><i class="fas fa-star"></i> 4.9★ Rating</div>
        <div class="trust-item"><i class="fas fa-clock"></i> 30 min delivery</div>
        <div class="trust-item"><i class="fas fa-leaf"></i> Fresh daily</div>
      </div>
    </div>
    <div class="hero-visual">
      <div class="hero-plate">🧇</div>
      <div class="hero-badge"><span class="badge-emoji">🍦</span><div class="badge-text"><strong>Cookie Dough</strong><span>₹169</span></div></div>
      <div class="hero-badge"><span class="badge-emoji">🥞</span><div class="badge-text"><strong>Nutella Tower</strong><span>₹209</span></div></div>
      <div class="hero-badge"><span class="badge-emoji">🍫</span><div class="badge-text"><strong>Fudge Brownie</strong><span>₹129</span></div></div>
    </div>
  </div>
  <div class="hero-wave"><svg viewBox="0 0 1440 70" preserveAspectRatio="none"><path d="M0,35 C360,70 1080,0 1440,35 L1440,70 L0,70 Z"/></svg></div>
</section>

<!-- Categories -->
<section class="section">
  <div class="container">
    <h2 class="section-title">Browse by <span class="accent">Category</span></h2>
    <div class="cat-grid">
      <?php foreach ($categories as $cat): ?>
      <a href="<?= SITE_URL ?>/pages/menu.php?cat=<?= $cat['slug'] ?>" class="cat-card">
        <div class="cat-emoji"><?= $cat['emoji'] ?></div>
        <h3><?= htmlspecialchars($cat['name']) ?></h3>
        <p><?= htmlspecialchars($cat['tagline']) ?></p>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Featured -->
<section class="section section-alt">
  <div class="container">
    <div class="section-header">
      <h2 class="section-title">⭐ Customer <span class="accent">Favourites</span></h2>
      <a href="<?= SITE_URL ?>/pages/menu.php" class="btn btn-outline btn-sm">View All <i class="fas fa-arrow-right"></i></a>
    </div>
    <div class="food-grid">
      <?php foreach ($featured as $f): ?>
      <div class="food-card">
        <div class="food-img"><?= $f['cat_emoji'] ?></div>
        <div class="food-body">
          <span class="cat-pill pill-<?= $f['cat_slug'] ?>"><?= htmlspecialchars($f['cat_name']) ?></span>
          <div class="food-top">
            <h3 class="food-name"><?= htmlspecialchars($f['name']) ?></h3>
            <button class="wish-btn" onclick="toggleWish(<?= $f['id'] ?>, this)" title="Wishlist">🤍</button>
          </div>
          <p class="food-desc"><?= htmlspecialchars($f['description']) ?></p>
          <div class="food-footer">
            <span class="food-price">₹<?= number_format($f['price'], 0) ?></span>
            <span class="food-rating"><span class="star-gold">★</span> <?= $f['rating'] ?></span>
          </div>
          <form class="atc-form" action="<?= SITE_URL ?>/api/cart.php" method="POST">
            <input type="hidden" name="action" value="add"/>
            <input type="hidden" name="food_id" value="<?= $f['id'] ?>"/>
            <button type="submit"><i class="fas fa-plus"></i> Add to Cart</button>
          </form>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- How It Works -->
<section class="section">
  <div class="container">
    <h2 class="section-title">How It <span class="accent">Works</span></h2>
    <div class="steps-grid">
      <div class="step-card"><div class="step-num">01</div><div class="step-icon">🔍</div><h3>Browse Menu</h3><p>Explore waffles, pancakes, ice creams, milkshakes, waffle cakes, and brownies.</p></div>
      <div class="step-card"><div class="step-num">02</div><div class="step-icon">🛒</div><h3>Add to Cart</h3><p>Pick your favourites and mix & match freely. No limits!</p></div>
      <div class="step-card"><div class="step-num">03</div><div class="step-icon">💳</div><h3>Easy Payment</h3><p>Pay via UPI, card, or cash on delivery — always secure.</p></div>
      <div class="step-card"><div class="step-num">04</div><div class="step-icon">🚀</div><h3>Fresh Delivery</h3><p>Hot waffles and cold ice cream — perfectly timed to your door!</p></div>
    </div>
  </div>
</section>

<!-- Testimonials -->
<section class="section section-alt">
  <div class="container">
    <h2 class="section-title">What Our <span class="accent">Guests Say</span></h2>
    <div class="testi-grid">
      <div class="testi-card"><div class="testi-stars">★★★★★</div><p>"The Nutella Banana Waffle is absolutely incredible — crispy, warm and perfectly topped. I order it every single week!"</p><div class="reviewer"><div class="avatar">A</div><div><strong>Ananya Sharma</strong><small>Hyderabad</small></div></div></div>
      <div class="testi-card"><div class="testi-stars">★★★★★</div><p>"The Oreo Overload Milkshake is the thickest shake I've ever had. And the Belgian Waffle Cake is a showstopper!"</p><div class="reviewer"><div class="avatar">R</div><div><strong>Rohan Mehta</strong><small>Bangalore</small></div></div></div>
      <div class="testi-card"><div class="testi-stars">★★★★★</div><p>"Nutella Brownie + Lotus Biscoff Shake = the perfect evening. This is my absolute go-to dessert spot!"</p><div class="reviewer"><div class="avatar">P</div><div><strong>Priya Reddy</strong><small>Chennai</small></div></div></div>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="cta-section">
  <div class="container">
    <h2>Ready to Indulge? 🧇</h2>
    <p>Sign up today and get ₹50 off your very first order!</p>
    <a href="<?= SITE_URL ?>/pages/register.php" class="btn btn-outline btn-lg" style="border-color:var(--brown);color:var(--brown);background:rgba(255,255,255,.2);">Get Started Free</a>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
<script>const BASE_URL = '<?= SITE_URL ?>';</script>
